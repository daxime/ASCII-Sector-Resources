Run asciisec.exe to start the game.

This game requires SDL2, SDL2_mixer and SDL2_image.
